//Name: Janak Parajuli
//Subject: Programming (2019/2020)
//Case Study II

//Define the dimension of the plot
const PLOT_WIDTH = 600;
const PLOT_HEIGHT = 400;
//Define global variables for storing the data content
let data_upv, data_silla;
// dimple.js variables
let svg, chart;
//Declare onload property of window. It calls the main function upon loading
window.onload = main;
//Define the main function
function main () {
  initPlot("#myChart");
  attachListeners();
}
//Define a function to attach listeners to button click events.
  function attachListeners(){
  //Define the button variables for accessing properties from HTML button
  let btnUpdate = document.getElementById("btnUpdate");
  let btnClear = document.getElementById("btnClear");

  //add event listener to both button variables
  btnUpdate.addEventListener("click", loadData);
  btnClear.addEventListener("click", clearPlot);

}
//Define a function loadData
function loadData(){
  //contains two variables with the data to visualize
  //First, store data from Pista de Silla
  data_silla = [
    {
      "Date": "1/8/2019",
      "PM2.5": 16,
      "PM10": 20
    },
    {
      "Date": "2/8/2019",
      "PM2.5": 14,
      "PM10": 23
    },
    {
      "Date": "3/8/2019",
      "PM2.5": 15,
      "PM10": 17
    },
    {
      "Date": "4/8/2019",
      "PM2.5": 14,
      "PM10": 16
    },
    {
      "Date": "5/8/2019",
      "PM2.5": 21,
      "PM10": 26
    },
    {
      "Date": "6/8/2019",
      "PM2.5": 30,
      "PM10": 31
    },
    {
      "Date": "7/8/2019",
      "PM2.5": 0,
      "PM10": 0
    },
    {
      "Date": "8/8/2019",
      "PM2.5": 27,
      "PM10": 24
    },
    {
      "Date": "9/8/2019",
      "PM2.5": 16,
      "PM10": 35
    },
    {
      "Date": "10/8/2019",
      "PM2.5": 20,
      "PM10": 22
    },
    {
      "Date": "11/8/2019",
      "PM2.5": 0,
      "PM10": 0
    },
    {
      "Date": "12/8/2019",
      "PM2.5": 15,
      "PM10": 14
    },
    {
      "Date": "13/08/2019",
      "PM2.5": 11,
      "PM10": 16
    },
    {
      "Date": "14/08/2019",
      "PM2.5": 17,
      "PM10": 16
    },
    {
      "Date": "15/08/2019",
      "PM2.5": 17,
      "PM10": 17
    },
    {
      "Date": "16/08/2019",
      "PM2.5": 15,
      "PM10": 15
    },
    {
      "Date": "17/08/2019",
      "PM2.5": 0,
      "PM10": 0
    },
    {
      "Date": "18/08/2019",
      "PM2.5": 0,
      "PM10": 0
    },
    {
      "Date": "19/08/2019",
      "PM2.5": 0,
      "PM10": 0
    },
    {
      "Date": "20/08/2019",
      "PM2.5": 16,
      "PM10": 23
    },
    {
      "Date": "21/08/2019",
      "PM2.5": 11,
      "PM10": 18
    },
    {
      "Date": "22/08/2019",
      "PM2.5": 10,
      "PM10": 22
    },
    {
      "Date": "23/08/2019",
      "PM2.5": 13,
      "PM10": 16
    },
    {
      "Date": "24/08/2019",
      "PM2.5": 0,
      "PM10": 0
    },
    {
      "Date": "25/08/2019",
      "PM2.5": 0,
      "PM10": 0
    },
    {
      "Date": "26/08/2019",
      "PM2.5": 0,
      "PM10": 0
    },
    {
      "Date": "27/08/2019",
      "PM2.5": 0,
      "PM10": 0
    },
    {
      "Date": "28/08/2019",
      "PM2.5": 14,
      "PM10": 29
    },
    {
      "Date": "29/08/2019",
      "PM2.5": 18,
      "PM10": 31
    },
    {
      "Date": "30/08/2019",
      "PM2.5": 20,
      "PM10": 32
    },
    {
      "Date": "31/08/2019",
      "PM2.5": 18,
      "PM10": 30
    }
  ];
  //Another data of universidad politecnica
  data_upv = [
    {
      "Date": "1/8/2019",
      "PM2.5": 11,
      "PM10": 16
    },
    {
      "Date": "2/8/2019",
      "PM2.5": 11,
      "PM10": 15
    },
    {
      "Date": "3/8/2019",
      "PM2.5": 10,
      "PM10": 15
    },
    {
      "Date": "5/8/2019",
      "PM2.5": 14,
      "PM10": 21
    },
    {
      "Date": "6/8/2019",
      "PM2.5": 20,
      "PM10": 29
    },
    {
      "Date": "7/8/2019",
      "PM2.5": 27,
      "PM10": 36
    },
    {
      "Date": "8/8/2019",
      "PM2.5": 20,
      "PM10": 28
    },
    {
      "Date": "9/8/2019",
      "PM2.5": 12,
      "PM10": 25
    },
    {
      "Date": "10/8/2019",
      "PM2.5": 14,
      "PM10": 20
    },
    {
      "Date": "11/8/2019",
      "PM2.5": 13,
      "PM10": 17
    },
    {
      "Date": "12/8/2019",
      "PM2.5": 11,
      "PM10": 17
    },
    {
      "Date": "13/08/2019",
      "PM2.5": 8,
      "PM10": 16
    },
    {
      "Date": "14/08/2019",
      "PM2.5": 10,
      "PM10": 16
    },
    {
      "Date": "15/08/2019",
      "PM2.5": 11,
      "PM10": 14
    },
    {
      "Date": "16/08/2019",
      "PM2.5": 9,
      "PM10": 12
    },
    {
      "Date": "17/08/2019",
      "PM2.5": 10,
      "PM10": 12
    },
    {
      "Date": "18/08/2019",
      "PM2.5": 10,
      "PM10": 12
    },
    {
      "Date": "19/08/2019",
      "PM2.5": 11,
      "PM10": 14
    },
    {
      "Date": "20/08/2019",
      "PM2.5": 12,
      "PM10": 25
    },
    {
      "Date": "21/08/2019",
      "PM2.5": 6,
      "PM10": 9
    },
    {
      "Date": "22/08/2019",
      "PM2.5": 8,
      "PM10": 10
    },
    {
      "Date": "23/08/2019",
      "PM2.5": 11,
      "PM10": 15
    },
    {
      "Date": "24/08/2019",
      "PM2.5": 14,
      "PM10": 17
    },
    {
      "Date": "25/08/2019",
      "PM2.5": 15,
      "PM10": 17
    },
    {
      "Date": "26/08/2019",
      "PM2.5": 18,
      "PM10": 20
    },
    {
      "Date": "27/08/2019",
      "PM2.5": 9,
      "PM10": 12
    },
    {
      "Date": "28/08/2019",
      "PM2.5": 10,
      "PM10": 13
    },
    {
      "Date": "29/08/2019",
      "PM2.5": 11,
      "PM10": 14
    },
    {
      "Date": "30/08/2019",
      "PM2.5": 14,
      "PM10": 18
    },
    {
      "Date": "31/08/2019",
      "PM2.5": 13,
      "PM10": 16
    }
  ];
  updatePlot();
}
//Define a function to update the plot
function updatePlot(){
//Access the parameters of drawPlot function to plot them
let data = document.getElementById("station_sel").value;
let type = document.getElementById("type_sel").value;
let measurement = document.getElementById("measurement_sel").value;
//Choose which data to plot
if(data == 'upv'){
  drawPlot(data_upv, measurement, type);
  }else if(data == 'silla'){
    drawPlot(data_silla, measurement, type);
  }
}
//Define a svg variable with height, width and body on which data are plotted.
function initPlot(el_id = "body") {
  svg = dimple.newSvg(el_id, PLOT_WIDTH, PLOT_HEIGHT);
}


/*
  Dimple.js Chart construction code
*/
function drawPlot(dataset, measurement, type) {
  console.log("This is type: "+type);
//If there is previously drawn graph, clear it first.
  clearPlot();

  chart = new dimple.chart(svg, dataset);

  let x = chart.addCategoryAxis("x", "Date");
  x.addOrderRule("Date");
  chart.addMeasureAxis("y", measurement);
  if (type=="bar") {
    chart.addSeries(type, dimple.plot.bar);
  } else if (type=="bubble") {
    chart.addSeries(type, dimple.plot.bubble);
  } else {
    chart.addSeries(type, dimple.plot.line);
  }
//As we have all the parameter, draw them accordingly
  chart.draw();
}

/*
  D3.js code
*/
//Define a function to clear the drawing area.
function clearPlot() {
  if (chart!=undefined)
    d3.select("g").remove();
}

